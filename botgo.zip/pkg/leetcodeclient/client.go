package leetcodeclient

import (
	"encoding/json"
	"fmt"
	"strconv"
	"strings"
	"time"
)

// LeetCodeTask is a necessary information about task at LeetCode
type LeetCodeTask struct {
	QuestionID uint64   `json:"questionId,string"`
	ItemID     uint64   `json:"itemId,string"`
	Title      string   `json:"questionTitle"`
	Content    string   `json:"content"`
	Hints      []string `json:"hints"`
}

type chaptersDesc struct {
	Data struct {
		Chapters []struct {
			Items []struct {
				ID    string
				Title string
			}
		}
	}
}

type questionDesc struct {
	Data struct {
		Question LeetCodeTask
	}
}

type titleSlugDesc struct {
	Data struct {
		Item struct {
			Question struct {
				QuestionID string
				Title      string
				TitleSlug  string
			}
		}
	}
}

// LeetcodeClient represents minimal set of methods required from any kind of Leetcode client
type LeetcodeClient interface {
	GetDailyTaskItemID(time.Time) string
	GetQuestionDetailsByItemID(string) LeetCodeTask
}

// LeetCodeGraphQlClient realization of GraphQL client.
// Potentially supports different requester types
type LeetCodeGraphQlClient struct {
	getChaptersReq   graphQlRequest
	getSlugReq       graphQlRequest
	getQuestionReq   graphQlRequest
	graphQlRequester graphQlRequesterInt
}

func (c *LeetCodeGraphQlClient) getDailyTaskItemsIdsForMonth(date time.Time) ([]string, error) {
	chaptersReq := c.getChaptersReq

	cardSlug := c.getSlug(date)
	chaptersReq.Variables = map[string]string{"cardSlug": cardSlug}
	chaptersReq.Query = "query GetChaptersWithItems($cardSlug: String!) { chapters(cardSlug: $cardSlug) { items {id title type }}}"
	request, err := c.graphQlRequester.requestGraphQl(chaptersReq)
	if err != nil {
		return []string{}, err
	}
	parsed := chaptersDesc{}
	err = json.Unmarshal(request, &parsed)
	resp := []string{}
	for _, week := range parsed.Data.Chapters {
		for i, item := range week.Items {
			if i == 0 {
				continue
			}
			resp = append(resp, item.ID)
		}
	}
	return resp, err
}

func (c *LeetCodeGraphQlClient) getDailyTaskItemIDForDate(date time.Time) (string, error) {
	forMonth, err := c.getDailyTaskItemsIdsForMonth(date)
	if date.Day() > len(forMonth) {
		return "", fmt.Errorf("can't get %d task for month %s. Only %d tasks isset", date.Day(), date.Month().String(), len(forMonth))
	}
	return forMonth[date.Day()-1], err
}

// GetDailyTaskItemID retrieve itemId for task of the day on provided date
func (c *LeetCodeGraphQlClient) GetDailyTaskItemID(date time.Time) (string, error) {
	return c.getDailyTaskItemIDForDate(date)
}

func (c *LeetCodeGraphQlClient) getSlug(date time.Time) string {
	return fmt.Sprintf("%s-leetcoding-challenge-%d", strings.ToLower(date.Month().String()), date.Year())
}

func (c *LeetCodeGraphQlClient) getQuestionSlug(itemID string) (string, error) {
	slugReq := c.getSlugReq
	slugReq.Variables["itemId"] = itemID
	request, err := c.graphQlRequester.requestGraphQl(slugReq)
	if err != nil {
		return "", err
	}
	parsed := titleSlugDesc{}
	err = json.Unmarshal(request, &parsed)
	return parsed.Data.Item.Question.TitleSlug, err
}

// GetQuestionDetailsByItemID provides all details of questions: title, text, hints by provided itemID
func (c *LeetCodeGraphQlClient) GetQuestionDetailsByItemID(itemID string) (LeetCodeTask, error) {
	questionReq := c.getQuestionReq
	questionSlug, err := c.getQuestionSlug(itemID)
	questionReq.Variables["titleSlug"] = questionSlug
	if err != nil {
		return LeetCodeTask{}, err
	}
	request, err := c.graphQlRequester.requestGraphQl(c.getQuestionReq)
	if err != nil {
		return LeetCodeTask{}, err
	}
	parsed := questionDesc{}
	err = json.Unmarshal(request, &parsed)
	if err != nil {
		return parsed.Data.Question, err
	}
	parsed.Data.Question.ItemID, err = strconv.ParseUint(itemID, 10, 64)
	return parsed.Data.Question, err
}

// GetDailyTask shortcut of GetDailyTaskItemID and GetQuestionDetailsByItemID
func (c *LeetCodeGraphQlClient) GetDailyTask(date time.Time) (LeetCodeTask, error) {
	itemID, err := c.GetDailyTaskItemID(date)
	if err != nil {
		return LeetCodeTask{}, err
	}
	task, err := c.GetQuestionDetailsByItemID(itemID)
	return task, err
}

// NewLeetCodeGraphQlClient construct LeetCode client with default values
func NewLeetCodeGraphQlClient() *LeetCodeGraphQlClient {
	return newLeetCodeGraphQlClient(newLeetCodeGraphQlRequester())
}

func newLeetCodeGraphQlClient(requester graphQlRequesterInt) *LeetCodeGraphQlClient {
	client := LeetCodeGraphQlClient{
		getChaptersReq: graphQlRequest{OperationName: "GetChaptersWithItems"},
		getSlugReq: graphQlRequest{
			OperationName: "GetItem",
			Variables:     make(map[string]string),
			Query:         "query GetItem($itemId: String!) {item(id: $itemId) { question { questionId title titleSlug }}}",
		},
		getQuestionReq: graphQlRequest{
			OperationName: "GetQuestion",
			Variables:     make(map[string]string),
			Query:         "query GetQuestion($titleSlug: String!) {question(titleSlug: $titleSlug) { questionId questionTitle categoryTitle submitUrl content urlManager hints}}",
		},
		graphQlRequester: requester,
	}
	return &client
}
