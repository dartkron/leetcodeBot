package leetcodeclient

import (
	"bytes"
	"encoding/json"
	"io/ioutil"
	"net/http"
)

type graphQlRequesterInt interface {
	requestGraphQl(request graphQlRequest) ([]byte, error)
}

type leetCodeGraphQlRequester struct {
	GraphQlURL string
}

type graphQlRequest struct {
	OperationName string            `json:"operationName"`
	Variables     map[string]string `json:"variables"`
	Query         string            `json:"query"`
}

func (requester *leetCodeGraphQlRequester) requestGraphQl(request graphQlRequest) ([]byte, error) {
	b := new(bytes.Buffer)
	err := json.NewEncoder(b).Encode(request)
	if err != nil {
		return []byte{}, err
	}
	r, err := http.Post(requester.GraphQlURL, "application/json", b)
	if err != nil {
		return []byte{}, err
	}
	return ioutil.ReadAll(r.Body)
}

func newLeetCodeGraphQlRequester() *leetCodeGraphQlRequester {
	return &leetCodeGraphQlRequester{"https://leetcode.com/graphql"}
}
